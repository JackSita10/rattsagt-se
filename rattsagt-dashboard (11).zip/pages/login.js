export default function Login() {
  return <h2>Logga in</h2>;
}