# Dashboard Project

This is a professional-grade dashboard with authentication.