export default function Home() {
  return <h1>Välkommen till Rätt Sagt Dashboard</h1>;
}