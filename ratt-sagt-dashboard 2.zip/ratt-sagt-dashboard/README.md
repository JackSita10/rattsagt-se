# Rätt Sagt – Dashboard

Detta är en dashboard för projektet Rätt Sagt.