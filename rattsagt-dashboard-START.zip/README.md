# Rätt Sagt – Dashboard

Startfil för Rätt Sagt-projektet.